from django.contrib import admin
from .models import Summary

admin.site.register(Summary)