from django.db import models

class Summary(models.Model):
    title = models.CharField(max_length=100)

    body = models.TextField()

    #picture = models.ImageField()

    #above is where I would have liked to include an image field for each
    #summary in my portfolio

    #Doing so would have required me to install Pillow

    def __str__(self):
        return self.title[:50]
    