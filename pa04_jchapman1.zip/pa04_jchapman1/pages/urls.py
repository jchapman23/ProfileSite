from django.urls import path
from .views import *

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('about/', AboutPageView.as_view(), name='about'),
    path('portfolio/', PortPageView.as_view(), name='portfolio'),
    path('contact/', ContactPageView.as_view(), name='contact'),
    path('summary/<int:pk>/', SummaryDetailView.as_view(), name='highlight')
]
